Vax = 13800/ sqrt (3);
Vth = transpose([Vax,Vax*exp(i*4*pi/3),Vax*exp(i*2*pi/3)]);                    % vetor coluna da fonte de tensao do equivalente de Thevenin do no da subestacao

Zax = (Vax ^2) /(((1/3) *10E8)*( cos (80* pi /180) - 1i* sin (80* pi /180) )); % Impedancia equivalente do Thevenin do no da subestacao                                                                
Yth = [1/Zax,0    ,0                                                           % Matriz de admitancia do equivalente de Norton do no da subestacao
       0    ,1/Zax,0
       0    ,0    ,1/Zax];                                                     
Ith = Yth*Vth;                                                                 % vator coluna da fonte de corrente do equivalente de Norton do no da subestacao
Rmax = 10;                                                                     % Valor maximo da resistencia de falta

TOP069;
CAR069;
VOL069;

  ZcInv = zeros(3*n,3*n);
  %-----Cargas-----% % Ja invertida ,ou seja, pronta para somar em Y
  for i=2:n
     k=3*i-2;
     
     % mtCarga  = | 1/Za   0   0 |
     %            |  0  1/Zb   0 |
     %            |  0   0  1/Zc |
     %
     % Za=Zb=Zc
     
     % Calcula Za
     load = (13800^2) /(1000*( cargas (i,2) - 1j* cargas (i,2) .* tan( acos ( cargas (i,3)))));
     
     mtCarga = [ 1/load,0     ,0
                 0     ,1/load,0
                 0     ,0     ,1/load
                ];
            
     ZcInv(k:k+2,k:k+2) = mtCarga;  
  end
  %----------------%
 
  %-----Montagem da matriz de admitâncias primitivas-----%
  distancia = 0;
  [n,m] = size(topologia);
  Ypr = zeros(3*n,3*n);
  
  for i=1:n
     k=3*i-2;
     distancia = topologia(i, 3);
     
     % matrizAd = | Ya   0   0 |
     %            |  0  Yb   0 |
     %            |  0   0  Yc |
     
     matrizAd = [ 1 / (topologia(i, 4) + 1j*topologia(i, 5)) , 1 / (topologia(i, 6) + 1j*topologia(i, 7)) , 1 / (topologia(i, 8) + 1j*topologia(i, 9))
                  1 / (topologia(i,10) + 1j*topologia(i,11)) , 1 / (topologia(i,12) + 1j*topologia(i,13)) , 1 / (topologia(i,14) + 1j*topologia(i,15))
                  1 / (topologia(i,16) + 1j*topologia(i,17)) , 1 / (topologia(i,18) + 1j*topologia(i,19)) , 1 / (topologia(i,20) + 1j*topologia(i,21))
                ];
                
     matrizAd = (1 / distancia) * matrizAd;
     
     %Nao existem mutuas entre os ramos
     Ypr(k:k+2,k:k+2) = matrizAd;  
        
  end
  
  %-----Montagem da matriz de incidencias Q-----%
  
  countNos = 35;
  countRamos = n;
  um = eye(3);
  zero = zeros(3);
  
  Q = zeros(3*countRamos, 3*countNos);
  
  k=1;
  for i=1 : countRamos
    k = 3*i-2;
    p = topologia(i,1)/10; %pai (barra inicial)
    f = topologia(i,2)/10; %filho (barra final)
  
    Q( k:k+2 , 3*p-2:3*p) = um;
    Q( k:k+2 , 3*f-2:3*f) = -1 * um;
    
  end  

  
  for i = 1:3:3*countRamos
    for j = 1:3:3*countNos
      if((Q(i:i+2,j:j+2) ~= um ) | (Q(i:i+2,j:j+2) ~= -1 * um))
        Q(i:i+2,j:j+2) = zero;
      end
    end
  end
 
 Ypr=Ypr+ZcInv;
 Ybus=transpose(Q)*Ypr*Q;
 
 Yprf = zeros( 3*(n+1) , 3*(n+1) );
 Qf = zeros( 3*(countRamos+1) , 3*(countNos+1) );
   
