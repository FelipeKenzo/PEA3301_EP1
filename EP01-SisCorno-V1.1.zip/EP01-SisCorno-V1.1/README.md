# PEA3301_EP1
#Algoritmo para detecção de faltas em redes de distribuição.

Exercício-Programa da disciplina PEA3301 - Introdução aos Sistemas de Potência. O enunciado pode ser obtido [neste link](https://edisciplinas.usp.br/pluginfile.php/4491636/course/section/5812517/EP2019.pdf).

