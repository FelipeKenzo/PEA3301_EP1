function [Ybus]= calculaY(topologia,cargas,n,countNos,x,rx,pf,ff)
  
  um = eye(3);
  
  Ypr = zeros(3*(n+2),3*(n+2));
  %-----Montagem da matriz de admitancias primitivas-----%
  for i=1:n
     k=3*i-2;
     if (topologia(i,1) ~= pf)&&(topologia(i,2) ~= ff)
     distancia = topologia(i, 3);
     
     matrizAd = [ 1 / (topologia(i, 4) + 1j*topologia(i, 5)) , 1 / (topologia(i, 6) + 1j*topologia(i, 7)) , 1 / (topologia(i, 8) + 1j*topologia(i, 9))
                  1 / (topologia(i,10) + 1j*topologia(i,11)) , 1 / (topologia(i,12) + 1j*topologia(i,13)) , 1 / (topologia(i,14) + 1j*topologia(i,15))
                  1 / (topologia(i,16) + 1j*topologia(i,17)) , 1 / (topologia(i,18) + 1j*topologia(i,19)) , 1 / (topologia(i,20) + 1j*topologia(i,21))
                ];
                
     matrizAd = (1 / distancia) * matrizAd;
     Ypr(k:k+2,k:k+2) = matrizAd;
     
     else
     distancia = topologia(i, 3);
     
     matrizAd = [ 1 / (topologia(i, 4) + 1j*topologia(i, 5)) , 1 / (topologia(i, 6) + 1j*topologia(i, 7)) , 1 / (topologia(i, 8) + 1j*topologia(i, 9))
                  1 / (topologia(i,10) + 1j*topologia(i,11)) , 1 / (topologia(i,12) + 1j*topologia(i,13)) , 1 / (topologia(i,14) + 1j*topologia(i,15))
                  1 / (topologia(i,16) + 1j*topologia(i,17)) , 1 / (topologia(i,18) + 1j*topologia(i,19)) , 1 / (topologia(i,20) + 1j*topologia(i,21))
                ];
                
     mf1 = (1 / x) * matrizAd;
     Ypr(3*(n+2)-5:3*(n+2)-3,3*(n+2)-5:3*(n+2)-3) = mf1;
                
     mf2 = (1/(distancia-x)) * matrizAd;
     Ypr(3*(n+2)-2:3*(n+2),3*(n+2)-2:3*(n+2)) = mf2;
     
     end
        
  end
  %-------------------------------------------------------%
  
  Q = zeros(3*(n+2),3*(countNos+1));
  %-----Montagem da matriz de incidencias Q-----%
  for i=1 : n  
    if (topologia(i,1) ~= pf)&&(topologia(i,2) ~= ff)
      k = 3*i-2;
      p = topologia(i,1)/10; %pai (barra inicial)
      f = topologia(i,2)/10; %filho (barra final)
  
      Q( k:k+2 , 3*p-2:3*p) = um;
      Q( k:k+2 , 3*f-2:3*f) = -1 * um;  
    else
      k=3*(n+2);
      t=3*(countNos+1);
      Q( k-5:k-3,3*pf-2:3*pf) = um;
      Q( k-5:k-3,t-2:t) = -1 * um;
      Q( k-2:k,t-2:t) = um;
      Q( k-2:k,3*ff-2:3*ff) = -1 * um;
    end  
  end  
  
  ZcInv = zeros(3*(countNos+1),3*(countNos+1));
  %-----Cargas-----% % Ja invertida ,ou seja, pronta para somar em Y
  for i=2:n
     k=3*i-2;
    
     load = 3*(13800^2) /(1000*( cargas (i-1,2) - 1j* cargas (i-1,2) .* tan( acos ( cargas (i-1,3)))));
     
     mtCarga = [ 1/load,0     ,0
                 0     ,1/load,0
                 0     ,0     ,1/load
                ];
            
     ZcInv(k:k+2,k:k+2) = mtCarga;  
  end
   mtrx = [ 1/rx  ,0     ,0
            0     ,1/rx  ,0
            0     ,0     ,1/rx
          ];
            
   ZcInv(3*n+1:3*(n+1),3*n+1:3*(n+1)) = mtrx;
   Ybus=transpose(Q)*Ypr*Q;
   Ybus=Ybus+ZcInv;
   
   
   
   
   
   
   
   