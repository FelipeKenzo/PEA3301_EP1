TOP069;
CAR069;
VOL069;

[n,m] = size(topologia);

Vax = 13800/ sqrt (3);
Vth = transpose([Vax,Vax*exp(1j*4*pi/3),Vax*exp(1j*2*pi/3)]);                    % vetor coluna da fonte de tensao do equivalente de Thevenin do no da subestacao
Zax = (Vax ^2) /(((1/3) *10E8)*( cos (80* pi /180) - 1i* sin (80* pi /180) )); % Impedancia equivalente do Thevenin do no da subestacao                                                                
Yth = [1/Zax,0    ,0                                                           % Matriz de admitancia do equivalente de Norton do no da subestacao
       0    ,1/Zax,0
       0    ,0    ,1/Zax];                                                     
Ith = Yth*Vth;                                                                 % vator coluna da fonte de corrente do equivalente de Norton do no da subestacao
Rmax = 10;                                                                     % Valor maximo da resistencia de falta

I=zeros(3*(n+2),1);
I(1:3,1)=Ith;

for caso = 6:10                               %loop
    
    EmA = Emedido(caso,2)+1i*Emedido(caso,3);
    EmB = Emedido(caso,4)+1i*Emedido(caso,5);
    EmC = Emedido(caso,6)+1i*Emedido(caso,7);
    
    for trecho = 1:size(topologia,1)          %lopp que testa cada trecho
        
        pf=topologia(trecho,1)/10;
        ff=topologia(trecho,2)/10;
        
        for x = 1:50:(topologia(trecho,3)-1)  %loop que testa cada distancia com passo de 1m
            for rx = 0.1:2:Rmax               %loop que testa resistencia de 0.1 at� Rmax com passo 0.1 (ohm)
                Ybus= calculaY(topologia,cargas,n,35,x,rx,pf,ff);
            end
        end    
    end
end
   
